/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ucr.ac.cr.tm2100.g3.moveball;

import ucr.ac.cr.tm2100.g3.moveball.controller.ControllerFrame;

/**
 *
 * @author Aarón Galagarza
 */
public class MoveBall {

    public static void main(String[] args) {
        new ControllerFrame();
    }
}
